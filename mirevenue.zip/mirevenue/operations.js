$(document).ready(function () {
    $('input[type=radio][name=format]').change(function () {
        if (this.value === 'select') {
            $('#free_format').addClass("display-none");
            $('#select_format').removeClass("display-none");
        } else if (this.value === 'free') {
            $('#free_format').removeClass("display-none");
            $('#select_format').addClass("display-none");
        }
    });

    $('#select_product').change(function () {
        loadClientTypes();
    });

    $('#select_client_type').change(function () {
        loadAccountNumbers();
    });

    $('#select_client_type').change(function () {
        loadAccountNumbers();
    });

    $("#transaction_form").submit(function (e) {
        e.preventDefault();
        submitTransaction();
    });

    loadServices();
    loadProducts();

    let stringDate = new Date();
    $('#transaction_date').val(stringDate.getFullYear() + "" + ('0' + (stringDate.getMonth() + 1)).slice(-2) + "" + ('0' + stringDate.getDate()).slice(-2));

});

function submitTransaction() {
    //validate that all fields are populated
    $('#results').addClass("display-none");
    let csid = "";
    let accountNumber = "";

    if ($('#radio_select').is(':checked')) {
        if ($('#select_service')[0].selectedIndex === 0
            || $('#select_product')[0].selectedIndex === 0
            || $('#select_client_type')[0].selectedIndex === 0
            || $('#select_account')[0].selectedIndex === 0) {
            $('#results').text("Please populate all fields")
            $('#results').removeClass("display-none");
            return;
        } else {
            csid = $('#select_service').val();
            accountNumber = $('#select_account').val();
        }
    } else {
        if (!$('#csid').val() || !$('#account_number').val()) {
            $('#results').text("Please populate all fields")
            $('#results').removeClass("display-none");
            return;
        } else {
            csid = $('#csid').val();
            accountNumber = $('#account_number').val();
        }
    }

    if (!$('#amount').val()
        || !$('#transaction_date').val()) {
        $('#results').text("Please populate all fields")
        $('#results').removeClass("display-none");
        return;
    }

    //code to submit the transaction
    const data = {
        csid: csid,
        account_number: accountNumber,
        amount: $('#amount').val(),
        transaction_date: $('#transaction_date').val(),
        environment: $('#select_env').val()
    };

    $.ajax({
        url: "/submit",
        type: "POST",
        data: data,
        success: function (response) {
            $("body").removeClass("loading");
            $('#results').text(response.result_message);
            $('#results').removeClass("display-none");
        }
    });
}

function loadServices() {
    $.getJSON('/services.json', function (data) {
        data.forEach(function (obj) {
            $('#select_service').append($('<option>', {
                value: obj.csid,
                text: obj.name
            }));
        });
    });
}

function loadProducts() {
    $.getJSON('/accounts.json', function (data) {
        data.forEach(function (obj) {
            const optionExists = ($('#select_product option[value=' + obj.product_name + ']').length > 0);

            if (!optionExists) {
                $('#select_product').append("<option value='" + obj.product_name + "'>" + obj.product_name + "</option>");
            }
        });
        loadClientTypes();
    });
}


function loadClientTypes() {
    $('#select_client_type').empty();
    $('#select_client_type').append("<option value=''>Select</option>");
    $.getJSON('/accounts.json', function (data) {
        let product = $('#select_product').val();

        data.forEach(function (obj) {
            var optionExists = ($('#select_client_type option[value=' + obj.client_type + ']').length > 0);

            if (!optionExists && product.localeCompare(obj.product_name) === 0) {
                $('#select_client_type').append("<option value='" + obj.client_type + "'>" + obj.client_type + "</option>");
            }
        });
    });
}

function loadAccountNumbers() {
    $('#select_account').empty();
    $('#select_account').append("<option value=''>Select</option>");
    $.getJSON('/accounts.json', function (data) {
        let product = $('#select_product').val();
        let clientType = $('#select_client_type').val();

        data.forEach(function (obj) {
            const optionExists = ($('#select_account option[value=' + obj.account_number + ']').length > 0);

            if (!optionExists && product.localeCompare(obj.product_name) === 0 && clientType.localeCompare(obj.client_type) === 0) {
                $('#select_account').append("<option value='" + obj.account_number + "'>" + obj.account_number + "</option>");
            }
        });
    });
}
